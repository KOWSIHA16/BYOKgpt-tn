# Phase 6 — Reliability, Security, and Verification Implementation Plan

Enhance BYOKGPT with enterprise-grade reliability, end-to-end security hardening, robust multimodal attachment support (up to 10MB for JPEG, PNG, WEBP, PDF), true in-flight request cancellation, inline error recovery with one-tap Provider Switching, and automated test suites covering request construction, SSE parsing, and key persistence.

---

## User Review & Critical Decisions

> [!IMPORTANT]
> The following product decisions were confirmed during Phase 1:
> - **Multimodal Attachments**: Enforce a strict **10MB maximum limit** supporting images (`image/jpeg`, `image/png`, `image/webp`) and documents (`application/pdf`) with on-device validation.
> - **Provider Failure Recovery**: When a request fails (rate limits, network timeout, auth error), present an **Inline Error Card** directly on the message bubble featuring both **"Retry"** and **"Switch Provider"** action buttons so users can instantly failover to an alternative configured provider.
> - **Automated Testing Strategy**: Implement comprehensive unit & Robolectric tests for all three providers (Gemini, Claude, OpenAI) validating request serialization, SSE streaming, error parsing, attachment validation, and Keystore persistence, plus **live credential verification** if `GEMINI_API_KEY` is present in `BuildConfig`.

---

## 1. Architecture & Component Structure

```
┌────────────────────────────────────────────────────────────────────────┐
│                              BYOKGPT UI                                │
│                                                                        │
│   ┌────────────────────────────────────────────────────────────────┐   │
│   │                        Chat Screen                             │   │
│   │  [Top Bar: Model Chip | Drawer | Settings]                     │   │
│   │                                                                │   │
│   │  [Message List (LazyColumn)]                                   │   │
│   │   - User Bubble (Text + Attachment Chip Preview)               │   │
│   │   - AI Response Bubble (Live Streaming Cursor / Markdown)      │   │
│   │   - Inline Error Card:                                         │   │
│   │     [⚠️ Quota / Rate Limit Exceeded]                           │   │
│   │     [🔄 Retry]   [🔀 Switch Provider]                          │   │
│   │                                                                │   │
│   │  [Bottom Composer]                                             │   │
│   │   - Attachment Button (Image & PDF Pickers with <= 10MB check) │   │
│   │   - Text Input + [Send / Stop Button]                          │   │
│   └───────────────────────────────┬────────────────────────────────┘   │
│                                   │                                    │
│                                   ▼                                    │
│   ┌────────────────────────────────────────────────────────────────┐   │
│   │                        ChatViewModel                           │   │
│   │  - Manages in-flight OkHttp Call lifecycle (cancel on stop)    │   │
│   │  - Prevents duplicate sends / ignores stale stream chunks      │   │
│   │  - Validates attachments via AttachmentValidator               │   │
│   └─────────────────┬──────────────────────────────┬───────────────┘   │
│                     │                              │                   │
│                     ▼                              ▼                   │
│   ┌──────────────────────────────────┐   ┌─────────────────────────┐   │
│   │     Provider Client Layer        │   │    Security & Storage   │   │
│   │  - GeminiClient (REST/SSE + img) │   │  - SecureKeyStorage     │   │
│   │  - ClaudeClient (REST/SSE + doc) │   │    (Keystore AES-256)   │   │
│   │  - OpenAiClient (REST/SSE + img) │   │  - Backup Exclusions    │   │
│   │  - Endpoint & Model Validator    │   │  - Local Room Database  │   │
│   │  - Sanitized Diagnostic Logs     │   │    (Zero key exposure)  │   │
│   └──────────────────────────────────┘   └─────────────────────────┘   │
└────────────────────────────────────────────────────────────────────────┘
```

---

## 2. Reliability & Resilience Hardening

1. **In-Flight Cancellation & Stale Stream Prevention**:
   - Save active `okhttp3.Call` references during streaming.
   - When the user taps **Stop** or switches/deletes chats, call `call.cancel()` directly on the HTTP call in addition to canceling the Coroutine job, terminating the network connection immediately and saving bandwidth/tokens.
   - Tag each generation session with a unique UUID `turnId`. Silently discard any incoming chunks that do not match the current active `turnId`, preventing stale streaming updates.
2. **Preventing Duplicate Sends & Stuck States**:
   - Disable input and Send actions while `isStreaming` is active (Send button dynamically converts to Stop).
   - Ensure `finally` blocks in `ChatViewModel` always reset `isStreaming = false` and `streamingMessageId = null` even under unexpected runtime exceptions.
3. **Multimodal Attachments (<= 10MB, Images & PDF)**:
   - Implement `AttachmentValidator`:
     - Verifies file size does not exceed `10 * 1024 * 1024` bytes.
     - Verifies MIME types: `image/jpeg`, `image/png`, `image/webp`, `application/pdf`.
     - Generates base64 data for API payloads with proper provider formatting:
       - **Gemini**: `inlineData` with `mimeType` and `data`.
       - **Claude**: Image sources (`base64`) or document sources (`application/pdf`).
       - **OpenAI**: `image_url` data URIs (`data:image/...;base64,...`).
     - Rejects oversized files with an intuitive user warning before sending.
4. **Provider-Specific Error Parsing**:
   - **Google Gemini**: Parse `error.code`, `error.message`, and `error.status` (distinguish `RESOURCE_EXHAUSTED` / 429 from `INVALID_ARGUMENT` / 400).
   - **Anthropic Claude**: Parse `error.type` and `error.message` (e.g. `rate_limit_error`, `authentication_error`, `invalid_request_error`).
   - **OpenAI**: Parse `error.code`, `error.type`, and `error.message`.
   - Clear classification into `isRateLimit`, `isAuthError`, and `isNetworkError`.
5. **Inline Failover & Switch Provider UI**:
   - When an assistant turn fails, render an inline card with:
     - Clear description of the failure reason.
     - **Retry** button: Re-sends the turn with current settings.
     - **Switch Provider** button: Opens `ModelPickerSheet` pre-filtered to alternative working providers.

---

## 3. Security Hardening

1. **Zero Secret Logging**:
   - Audit all OkHttp interceptors and logging statements: verify that `Authorization: Bearer ...`, `x-api-key: ...`, and `?key=...` query parameters are redacted from logs and diagnostic strings.
   - Exclude sensitive user prompts and API keys from crash reports.
2. **Android Keystore AES-256-GCM Storage**:
   - Confirm `SecureKeyStorage` encrypts keys using hardware-backed `AndroidKeyStore` keys with `AES/GCM/NoPadding` and 12-byte random IVs.
3. **Android Backup & Data-Export Rules**:
   - Update `app/src/main/res/xml/backup_rules.xml` and `data_extraction_rules.xml` to explicitly exclude `byokgpt_secure_keys.xml` from cloud backup and device transfer, ensuring encrypted blobs that rely on device-specific Keystore keys are never transferred to a different device.
   - Verify that Conversation Export copies only message text and role annotations, with zero secrets or keys included.

---

## 4. Automated Testing & Verification Suite

1. **Provider Request & Response Tests (`ProviderProtocolTest.kt`)**:
   - Gemini: JSON request serialization, multimodal parts, SSE candidate extraction, 429 rate limit parsing.
   - Claude: Header construction, `content_block_delta` SSE parsing, 401 invalid key error parsing.
   - OpenAI: `choices[0].delta.content` SSE parsing, `[DONE]` termination, error parsing.
2. **Attachment Validation Tests (`AttachmentValidatorTest.kt`)**:
   - Rejection of files > 10MB.
   - Acceptance of JPEG, PNG, WEBP, and PDF.
   - Rejection of unsupported formats (e.g. executables, videos).
3. **Keystore Encryption & Redaction Tests (`SecurityTest.kt`)**:
   - Encryption and decryption round-trip verification.
   - Verification that log sanitizers scrub API keys from URLs and headers.
4. **Live Credential Verification (`LiveCredentialTest.kt`)**:
   - If `BuildConfig.GEMINI_API_KEY` is set and non-empty, execute an automated verification call to Google Gemini `gemini-1.5-flash` and assert success.

---

## 5. Verification & Deliverable Artifacts

- Verify via `gradle :app:testDebugUnitTest`.
- Run final compilation via `compile_applet`.
- Package updated project archive into `BYOKGPT-updated.zip` and generate signed debug APK `app/build/outputs/apk/debug/app-debug.apk`.
- Provide a truthful, comprehensive verification report.

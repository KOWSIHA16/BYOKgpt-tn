package com.example.byokgpt.model

import com.example.R

enum class AiProvider(
    val displayName: String,
    val defaultModel: String,
    val defaultEndpoint: String,
    val iconResId: Int,
    val apiKeyPlaceholder: String,
    val docsUrl: String
) {
    GEMINI(
        displayName = "Google Gemini",
        defaultModel = "gemini-1.5-flash",
        defaultEndpoint = "https://generativelanguage.googleapis.com",
        iconResId = R.drawable.gemini,
        apiKeyPlaceholder = "AQ... or AIzaSy...",
        docsUrl = "https://aistudio.google.com/app/apikey"
    ),
    CLAUDE(
        displayName = "Anthropic Claude",
        defaultModel = "claude-3-5-sonnet-20241022",
        defaultEndpoint = "https://api.anthropic.com/v1",
        iconResId = R.drawable.anthropic,
        apiKeyPlaceholder = "sk-ant-api03-...",
        docsUrl = "https://console.anthropic.com/settings/keys"
    ),
    OPENAI(
        displayName = "OpenAI ChatGPT",
        defaultModel = "gpt-4o-mini",
        defaultEndpoint = "https://api.openai.com/v1",
        iconResId = R.drawable.openai,
        apiKeyPlaceholder = "sk-proj-...",
        docsUrl = "https://platform.openai.com/api-keys"
    );

    companion object {
        fun fromString(value: String): AiProvider = entries.find {
            it.name.equals(value, ignoreCase = true)
        } ?: GEMINI
    }
}

data class AiModel(
    val id: String,
    val displayName: String,
    val provider: AiProvider,
    val description: String = ""
)

object ModelCatalog {
    val models: List<AiModel> = listOf(
        // Google Gemini (First as selected)
        AiModel("gemini-1.5-flash", "Gemini 1.5 Flash", AiProvider.GEMINI, "Fast, lightweight multimodal model"),
        AiModel("gemini-1.5-pro", "Gemini 1.5 Pro", AiProvider.GEMINI, "High-intelligence multimodal reasoning"),
        AiModel("gemini-2.0-flash-exp", "Gemini 2.0 Flash (Exp)", AiProvider.GEMINI, "Next-gen experimental speed & fidelity"),

        // Anthropic Claude (Second)
        AiModel("claude-3-5-sonnet-20241022", "Claude 3.5 Sonnet", AiProvider.CLAUDE, "Most intelligent Claude model"),
        AiModel("claude-3-5-haiku-20241022", "Claude 3.5 Haiku", AiProvider.CLAUDE, "Fastest, compact Claude model"),
        AiModel("claude-3-opus-20240229", "Claude 3 Opus", AiProvider.CLAUDE, "Complex reasoning and analysis"),

        // OpenAI ChatGPT (Third)
        AiModel("gpt-4o-mini", "GPT-4o Mini", AiProvider.OPENAI, "Affordable, fast flagship mini"),
        AiModel("gpt-4o", "GPT-4o", AiProvider.OPENAI, "Flagship high-intelligence model"),
        AiModel("gpt-4-turbo", "GPT-4 Turbo", AiProvider.OPENAI, "High capability reasoning model")
    )

    fun getModelsFor(provider: AiProvider): List<AiModel> =
        models.filter { it.provider == provider }
}

enum class MessageRole {
    USER, ASSISTANT, SYSTEM;

    companion object {
        fun fromString(value: String): MessageRole = entries.find {
            it.name.equals(value, ignoreCase = true)
        } ?: USER
    }
}

enum class MessageStatus {
    SENT, STREAMING, SUCCESS, ERROR, CANCELLED;

    companion object {
        fun fromString(value: String): MessageStatus = entries.find {
            it.name.equals(value, ignoreCase = true)
        } ?: SUCCESS
    }
}

enum class ThemeMode {
    SYSTEM, LIGHT, DARK;

    companion object {
        fun fromString(value: String): ThemeMode = entries.find {
            it.name.equals(value, ignoreCase = true)
        } ?: SYSTEM
    }
}

data class ProviderConfig(
    val provider: AiProvider,
    val apiKey: String = "",
    val customEndpoint: String = "",
    val selectedModel: String = provider.defaultModel,
    val isEnabled: Boolean = true
)

data class AppSettings(
    val customInstructions: String = "",
    val userName: String = "User",
    val themeMode: ThemeMode = ThemeMode.SYSTEM,
    val fastAnswers: Boolean = true,
    val webSearch: Boolean = false,
    val visualAnswers: Boolean = true,
    val appLockEnabled: Boolean = false,
    val pinCode: String = ""
)

sealed class StreamChunk {
    data class Delta(val text: String) : StreamChunk()
    data class Done(val fullText: String) : StreamChunk()
    data class Error(
        val message: String,
        val isRateLimit: Boolean = false,
        val isAuthError: Boolean = false
    ) : StreamChunk()
}

package com.example.byokgpt.ui.chat

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.byokgpt.api.AiClientFactory
import com.example.byokgpt.data.AppDatabase
import com.example.byokgpt.data.ChatRepository
import com.example.byokgpt.data.ConversationEntity
import com.example.byokgpt.data.MessageEntity
import com.example.byokgpt.data.SettingsManager
import com.example.byokgpt.model.AiProvider
import com.example.byokgpt.model.Attachment
import com.example.byokgpt.model.AttachmentValidator
import com.example.byokgpt.model.MessageRole
import com.example.byokgpt.model.MessageStatus
import com.example.byokgpt.model.ProviderConfig
import com.example.byokgpt.model.StreamChunk
import com.example.byokgpt.security.SecureKeyStorage
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import okhttp3.Call
import java.util.UUID

class ChatViewModel(application: Application) : AndroidViewModel(application) {

    val secureKeyStorage = SecureKeyStorage(application)
    val settingsManager = SettingsManager(application)
    private val database = AppDatabase.getDatabase(application)
    val repository = ChatRepository(database.chatDao())

    val conversations: StateFlow<List<ConversationEntity>> = repository.conversations
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _currentConversationId = MutableStateFlow<String?>(null)
    val currentConversationId: StateFlow<String?> = _currentConversationId.asStateFlow()

    private val _currentMessages = MutableStateFlow<List<MessageEntity>>(emptyList())
    val currentMessages: StateFlow<List<MessageEntity>> = _currentMessages.asStateFlow()

    private val _selectedProvider = MutableStateFlow(secureKeyStorage.getCurrentProvider())
    val selectedProvider: StateFlow<AiProvider> = _selectedProvider.asStateFlow()

    private val _selectedModel = MutableStateFlow(
        secureKeyStorage.getSelectedModel(secureKeyStorage.getCurrentProvider())
    )
    val selectedModel: StateFlow<String> = _selectedModel.asStateFlow()

    private val _isStreaming = MutableStateFlow(false)
    val isStreaming: StateFlow<Boolean> = _isStreaming.asStateFlow()

    private val _streamingMessageId = MutableStateFlow<String?>(null)
    val streamingMessageId: StateFlow<String?> = _streamingMessageId.asStateFlow()

    private val _bannerDismissed = MutableStateFlow(false)
    val bannerDismissed: StateFlow<Boolean> = _bannerDismissed.asStateFlow()

    private val _pendingAttachment = MutableStateFlow<Attachment?>(null)
    val pendingAttachment: StateFlow<Attachment?> = _pendingAttachment.asStateFlow()

    private val _attachmentError = MutableStateFlow<String?>(null)
    val attachmentError: StateFlow<String?> = _attachmentError.asStateFlow()

    private var activeStreamJob: Job? = null
    private var activeCall: Call? = null
    private var currentTurnId: String? = null
    private var messageCollectionJob: Job? = null

    init {
        viewModelScope.launch {
            conversations.collect { convList ->
                if (_currentConversationId.value == null && convList.isNotEmpty()) {
                    selectConversation(convList.first().id)
                }
            }
        }
    }

    fun dismissBanner() {
        _bannerDismissed.value = true
    }

    fun clearAttachmentError() {
        _attachmentError.value = null
    }

    fun setPendingAttachment(uri: Uri) {
        val result = AttachmentValidator.loadAttachmentFromUri(getApplication(), uri)
        if (result.isSuccess) {
            _pendingAttachment.value = result.getOrNull()
            _attachmentError.value = null
        } else {
            _attachmentError.value = result.exceptionOrNull()?.message ?: "Failed to attach file."
        }
    }

    fun removePendingAttachment() {
        _pendingAttachment.value = null
        _attachmentError.value = null
    }

    fun selectConversation(id: String) {
        if (_currentConversationId.value == id) return
        stopGeneration()
        _currentConversationId.value = id

        messageCollectionJob?.cancel()
        messageCollectionJob = viewModelScope.launch {
            repository.getMessages(id).collect { messages ->
                _currentMessages.value = messages
            }
        }
    }

    fun startNewChat(provider: AiProvider = _selectedProvider.value, model: String = _selectedModel.value) {
        stopGeneration()
        viewModelScope.launch {
            val newConv = repository.createNewConversation("New Chat", provider, model)
            selectConversation(newConv.id)
        }
    }

    fun setProvider(provider: AiProvider) {
        _selectedProvider.value = provider
        secureKeyStorage.saveCurrentProvider(provider)
        val model = secureKeyStorage.getSelectedModel(provider)
        _selectedModel.value = model
    }

    fun setModel(modelId: String) {
        _selectedModel.value = modelId
        secureKeyStorage.saveSelectedModel(_selectedProvider.value, modelId)
    }

    fun sendMessage(promptText: String) {
        if (_isStreaming.value) return
        val trimmed = promptText.trim()
        val attachment = _pendingAttachment.value
        if (trimmed.isEmpty() && attachment == null) return

        val provider = _selectedProvider.value
        val model = _selectedModel.value
        val apiKey = secureKeyStorage.getApiKey(provider)
        val convId = _currentConversationId.value

        // Clear attachment from input bar
        _pendingAttachment.value = null

        viewModelScope.launch {
            val effectiveConvId = if (convId == null) {
                val newConv = repository.createNewConversation("New Chat", provider, model)
                _currentConversationId.value = newConv.id
                selectConversation(newConv.id)
                newConv.id
            } else {
                convId
            }

            // Save user message with attachment
            repository.saveMessage(
                conversationId = effectiveConvId,
                role = MessageRole.USER,
                content = trimmed,
                provider = provider,
                modelId = model,
                attachment = attachment
            )

            // If no API key configured, generate an inline error message
            if (apiKey.isEmpty()) {
                repository.saveMessage(
                    conversationId = effectiveConvId,
                    role = MessageRole.ASSISTANT,
                    content = "",
                    provider = provider,
                    modelId = model,
                    status = MessageStatus.ERROR,
                    errorMessage = "No API key configured for ${provider.displayName}. Tap Configure Key or Switch Provider below."
                )
                return@launch
            }

            // Create placeholder assistant message
            val assistantMsgId = UUID.randomUUID().toString()
            repository.saveMessage(
                conversationId = effectiveConvId,
                role = MessageRole.ASSISTANT,
                content = "",
                provider = provider,
                modelId = model,
                status = MessageStatus.STREAMING,
                messageId = assistantMsgId
            )

            executeStreaming(effectiveConvId, assistantMsgId, provider, model, apiKey)
        }
    }

    private fun executeStreaming(
        conversationId: String,
        assistantMsgId: String,
        provider: AiProvider,
        model: String,
        apiKey: String
    ) {
        stopGeneration()

        val turnId = UUID.randomUUID().toString()
        currentTurnId = turnId
        _isStreaming.value = true
        _streamingMessageId.value = assistantMsgId

        val client = AiClientFactory.getClient(provider)
        val config = ProviderConfig(
            provider = provider,
            apiKey = apiKey,
            customEndpoint = secureKeyStorage.getCustomEndpoint(provider),
            selectedModel = model
        )

        val systemPrompt = buildSystemPrompt()

        activeStreamJob = viewModelScope.launch {
            val history = repository.getMessagesSnapshot(conversationId)
            val fullContent = StringBuilder()

            try {
                client.streamChat(
                    messages = history,
                    systemPrompt = systemPrompt,
                    config = config,
                    model = model,
                    onCallCreated = { call ->
                        activeCall = call
                    }
                ).collect { chunk ->
                    if (currentTurnId != turnId) return@collect // Ignore stale turn chunks

                    when (chunk) {
                        is StreamChunk.Delta -> {
                            fullContent.append(chunk.text)
                            repository.updateMessage(
                                MessageEntity(
                                    id = assistantMsgId,
                                    conversationId = conversationId,
                                    role = MessageRole.ASSISTANT.name,
                                    content = fullContent.toString(),
                                    timestamp = System.currentTimeMillis(),
                                    status = MessageStatus.STREAMING.name,
                                    provider = provider.name,
                                    modelId = model
                                )
                            )
                        }
                        is StreamChunk.Done -> {
                            repository.updateMessage(
                                MessageEntity(
                                    id = assistantMsgId,
                                    conversationId = conversationId,
                                    role = MessageRole.ASSISTANT.name,
                                    content = chunk.fullText.ifEmpty { fullContent.toString() },
                                    timestamp = System.currentTimeMillis(),
                                    status = MessageStatus.SUCCESS.name,
                                    provider = provider.name,
                                    modelId = model
                                )
                            )
                        }
                        is StreamChunk.Error -> {
                            repository.updateMessage(
                                MessageEntity(
                                    id = assistantMsgId,
                                    conversationId = conversationId,
                                    role = MessageRole.ASSISTANT.name,
                                    content = fullContent.toString(),
                                    timestamp = System.currentTimeMillis(),
                                    status = MessageStatus.ERROR.name,
                                    errorMessage = chunk.message,
                                    provider = provider.name,
                                    modelId = model
                                )
                            )
                        }
                    }
                }
            } catch (e: Exception) {
                if (currentTurnId == turnId) {
                    repository.updateMessage(
                        MessageEntity(
                            id = assistantMsgId,
                            conversationId = conversationId,
                            role = MessageRole.ASSISTANT.name,
                            content = fullContent.toString(),
                            timestamp = System.currentTimeMillis(),
                            status = MessageStatus.ERROR.name,
                            errorMessage = e.localizedMessage ?: "Unexpected error during response generation.",
                            provider = provider.name,
                            modelId = model
                        )
                    )
                }
            } finally {
                if (currentTurnId == turnId) {
                    _isStreaming.value = false
                    _streamingMessageId.value = null
                    activeCall = null
                }
            }
        }
    }

    fun stopGeneration() {
        val currentId = _streamingMessageId.value
        val convId = _currentConversationId.value

        currentTurnId = null
        activeCall?.cancel()
        activeCall = null
        activeStreamJob?.cancel()
        _isStreaming.value = false
        _streamingMessageId.value = null

        if (currentId != null && convId != null) {
            viewModelScope.launch {
                val currentList = repository.getMessagesSnapshot(convId)
                val targetMsg = currentList.find { it.id == currentId }
                if (targetMsg != null && targetMsg.status == MessageStatus.STREAMING.name) {
                    repository.updateMessage(
                        targetMsg.copy(status = MessageStatus.CANCELLED.name)
                    )
                }
            }
        }
    }

    fun retryLastMessage() {
        if (_isStreaming.value) return
        val convId = _currentConversationId.value ?: return

        viewModelScope.launch {
            val list = repository.getMessagesSnapshot(convId)
            val lastUserMsg = list.findLast { it.role == MessageRole.USER.name } ?: return@launch

            // If the last message was an assistant error/cancelled, delete it before retry
            val lastMsg = list.lastOrNull()
            if (lastMsg != null && lastMsg.role == MessageRole.ASSISTANT.name) {
                repository.deleteMessage(lastMsg.id)
            }

            val provider = _selectedProvider.value
            val model = _selectedModel.value
            val apiKey = secureKeyStorage.getApiKey(provider)

            val assistantMsgId = UUID.randomUUID().toString()
            repository.saveMessage(
                conversationId = convId,
                role = MessageRole.ASSISTANT,
                content = "",
                provider = provider,
                modelId = model,
                status = MessageStatus.STREAMING,
                messageId = assistantMsgId
            )

            executeStreaming(convId, assistantMsgId, provider, model, apiKey)
        }
    }

    fun deleteConversation(id: String) {
        viewModelScope.launch {
            repository.deleteConversation(id)
            if (_currentConversationId.value == id) {
                val remaining = conversations.value.filter { it.id != id }
                if (remaining.isNotEmpty()) {
                    selectConversation(remaining.first().id)
                } else {
                    _currentConversationId.value = null
                    _currentMessages.value = emptyList()
                }
            }
        }
    }

    private fun buildSystemPrompt(): String? {
        val customInstructions = settingsManager.settings.value.customInstructions.trim()
        val userName = settingsManager.settings.value.userName.trim()
        val parts = mutableListOf<String>()

        if (userName.isNotEmpty() && userName != "User") {
            parts.add("You are addressing the user named $userName.")
        }
        if (customInstructions.isNotEmpty()) {
            parts.add("Custom user instructions:\n$customInstructions")
        }
        if (settingsManager.settings.value.fastAnswers) {
            parts.add("Provide direct, concise, and structured answers.")
        }
        if (settingsManager.settings.value.webSearch) {
            parts.add("Ground answers with verified facts and reference dates where applicable.")
        }
        return if (parts.isNotEmpty()) parts.joinToString("\n\n") else null
    }
}

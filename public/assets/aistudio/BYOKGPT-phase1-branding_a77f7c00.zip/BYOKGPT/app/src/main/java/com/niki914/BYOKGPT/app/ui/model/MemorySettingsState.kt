package com.niki914.zafiro.app.ui.model

import androidx.annotation.StringRes
import androidx.lifecycle.viewModelScope
import com.niki914.logging.Logger
import com.niki914.uikit.base.ComposeMVIViewModel
import com.niki914.zafiro.app.R
import com.niki914.zafiro.repo.XRepo
import com.niki914.zafiro.api.util.runCatchingCancellable
import com.niki914.zafiro.api.util.tryOrDefault
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.launch

data class MemorySettingsUiState(
    val items: List<String> = emptyList(),
    val isLoading: Boolean = true,
    val isSaving: Boolean = false,
    val editingDialog: MemoryEditDialogState? = null,
    val deleteConfirmation: MemoryDeleteConfirmationState? = null,
    val inlineError: MemoryInlineError? = null,
)

data class MemoryEditDialogState(
    val index: Int?,
    val value: String,
)

data class MemoryDeleteConfirmationState(
    val index: Int,
    val value: String,
)

sealed interface MemoryInlineError {
    data class LoadFailed(val message: String?, @StringRes val fallbackResId: Int) :
        MemoryInlineError

    data class SaveFailed(val message: String?, @StringRes val fallbackResId: Int) :
        MemoryInlineError

    data class DeleteFailed(val message: String?, @StringRes val fallbackResId: Int) :
        MemoryInlineError
}

sealed interface MemorySettingsIntent {
    data object Load : MemorySettingsIntent
    data object StartCreate : MemorySettingsIntent
    data class StartEdit(val index: Int) : MemorySettingsIntent
    data class EditValueChanged(val value: String) : MemorySettingsIntent
    data object DismissEditDialog : MemorySettingsIntent
    data object SaveEditDialog : MemorySettingsIntent
    data class RequestDeleteItem(val index: Int) : MemorySettingsIntent
    data object DismissDeleteConfirmation : MemorySettingsIntent
    data object ConfirmDeleteItem : MemorySettingsIntent
    data class DeleteItem(val index: Int) : MemorySettingsIntent
}

class MemorySettingsViewModel :
    ComposeMVIViewModel<MemorySettingsIntent, MemorySettingsUiState, Nothing>() {

    init {
        viewModelScope.launch {
            settingsChanges.collect {
                load()
            }
        }
    }

    override fun initUiState(): MemorySettingsUiState = MemorySettingsUiState()

    override suspend fun handleIntent(intent: MemorySettingsIntent) {
        when (intent) {
            MemorySettingsIntent.Load -> load()
            MemorySettingsIntent.StartCreate -> startCreate()
            is MemorySettingsIntent.StartEdit -> startEdit(intent.index)
            is MemorySettingsIntent.EditValueChanged -> updateEditValue(intent.value)
            MemorySettingsIntent.DismissEditDialog -> updateState {
                copy(editingDialog = null, inlineError = null)
            }

            MemorySettingsIntent.SaveEditDialog -> saveEditDialog()
            is MemorySettingsIntent.RequestDeleteItem -> requestDeleteItem(intent.index)
            MemorySettingsIntent.DismissDeleteConfirmation -> updateState {
                copy(deleteConfirmation = null, inlineError = null)
            }

            MemorySettingsIntent.ConfirmDeleteItem -> confirmDeleteItem()
            is MemorySettingsIntent.DeleteItem -> deleteItem(intent.index)
        }
    }

    private suspend fun load() {
        updateState { copy(isLoading = true) }
        val startedAtMs = System.currentTimeMillis()
        runCatchingCancellable {
            val loadedItems = XRepo.memory.list()
            Logger.d(
                LOG_TAG,
                "load items=${loadedItems.size} " +
                        "elapsedMs=${System.currentTimeMillis() - startedAtMs}"
            )
            updateState {
                copy(
                    items = loadedItems,
                    isLoading = false,
                    deleteConfirmation = null,
                    inlineError = null,
                )
            }
        }.onFailure { throwable ->
            Logger.w(LOG_TAG, "load failed reason=${throwable.message}")
            updateState {
                copy(
                    isLoading = false,
                    inlineError = MemoryInlineError.LoadFailed(
                        message = throwable.message,
                        fallbackResId = R.string.error_memory_load_failed,
                    ),
                )
            }
        }
    }

    private fun startCreate() {
        updateState {
            copy(
                editingDialog = MemoryEditDialogState(index = null, value = ""),
                deleteConfirmation = null,
                inlineError = null,
            )
        }
    }

    private fun startEdit(index: Int) {
        val value = currentState.items.getOrNull(index) ?: return
        updateState {
            copy(
                editingDialog = MemoryEditDialogState(index = index, value = value),
                deleteConfirmation = null,
                inlineError = null,
            )
        }
    }

    private fun updateEditValue(value: String) {
        val editingDialog = currentState.editingDialog ?: return
        updateState {
            copy(
                editingDialog = editingDialog.copy(value = value),
                inlineError = null,
            )
        }
    }

    private suspend fun saveEditDialog() {
        val dialog = currentState.editingDialog ?: return
        val trimmedValue = dialog.value.trim()
        if (trimmedValue.isBlank()) {
            updateState {
                copy(
                    editingDialog = null,
                    inlineError = null,
                )
            }
            return
        }

        updateState { copy(isSaving = true, inlineError = null) }
        runCatchingCancellable {
            val updatedItems = currentState.items.toMutableList().also { mutableItems ->
                val index = dialog.index
                if (index == null || index !in mutableItems.indices) {
                    mutableItems += trimmedValue
                } else {
                    mutableItems[index] = trimmedValue
                }
            }
            if (dialog.index == null) {
                XRepo.memory.add(trimmedValue)
            } else {
                XRepo.memory.update(dialog.index, trimmedValue)
            }
            Logger.i(
                LOG_TAG,
                "saveEditDialog succeeded index=${dialog.index} valueLength=${trimmedValue.length}"
            )
            updateState {
                copy(
                    items = updatedItems,
                    isSaving = false,
                    editingDialog = null,
                    deleteConfirmation = null,
                    inlineError = null,
                )
            }
            notifySettingsChanged()
        }.onFailure { throwable ->
            Logger.w(LOG_TAG, "saveEditDialog failed reason=${throwable.message}")
            updateState {
                copy(
                    isSaving = false,
                    inlineError = MemoryInlineError.SaveFailed(
                        message = throwable.message,
                        fallbackResId = R.string.error_memory_save_failed,
                    ),
                )
            }
        }
    }

    private fun requestDeleteItem(index: Int) {
        if (currentState.editingDialog != null) return
        val value = currentState.items.getOrNull(index) ?: return
        updateState {
            copy(
                deleteConfirmation = MemoryDeleteConfirmationState(index = index, value = value),
                inlineError = null,
            )
        }
    }

    private suspend fun confirmDeleteItem() {
        val deleteConfirmation = currentState.deleteConfirmation ?: return
        updateState { copy(deleteConfirmation = null) }
        deleteItem(deleteConfirmation.index)
    }

    private suspend fun deleteItem(index: Int) {
        val previousItems = currentState.items
        if (index !in previousItems.indices) return
        updateState { copy(isSaving = true, deleteConfirmation = null, inlineError = null) }
        runCatchingCancellable {
            XRepo.memory.delete(index)
            Logger.i(LOG_TAG, "deleteItem succeeded index=$index")
            updateState {
                copy(
                    items = previousItems.filterIndexed { itemIndex, _ -> itemIndex != index },
                    isSaving = false,
                    deleteConfirmation = null,
                    inlineError = null,
                )
            }
            notifySettingsChanged()
        }.onFailure { throwable ->
            Logger.w(LOG_TAG, "deleteItem failed index=$index reason=${throwable.message}")
            val reloadedItems = tryOrDefault(previousItems) { XRepo.memory.list() }
            updateState {
                copy(
                    items = reloadedItems,
                    isSaving = false,
                    deleteConfirmation = null,
                    inlineError = MemoryInlineError.DeleteFailed(
                        message = throwable.message,
                        fallbackResId = R.string.error_memory_delete_failed,
                    ),
                )
            }
        }
    }

    private fun notifySettingsChanged() {
        settingsChanges.tryEmit(Unit)
    }

    private companion object {
        private const val LOG_TAG = "niki914_zafiro_MemorySettingsViewModel"
        val settingsChanges = MutableSharedFlow<Unit>(extraBufferCapacity = 1)
    }
}

pluginManagement {
    repositories {
        google()
        gradlePluginPortal()
        mavenCentral()

        maven { url = uri("https://maven.aliyun.com/repository/public") }
        maven { url = uri("https://maven.aliyun.com/repository/google") }
        maven { url = uri("https://maven.aliyun.com/repository/central") }
        maven { url = uri("https://maven.aliyun.com/repository/jcenter") }
        maven { url = uri("https://maven.aliyun.com/repository/gradle-plugin") }
        maven { url = uri("https://jitpack.io") }

        maven { url = uri("https://chaquo.com/maven") }
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()

        maven { url = uri("https://maven.aliyun.com/repository/public") }
        maven { url = uri("https://maven.aliyun.com/repository/google") }
        maven { url = uri("https://maven.aliyun.com/repository/central") }
        maven { url = uri("https://maven.aliyun.com/repository/jcenter") }
        maven { url = uri("https://maven.aliyun.com/repository/gradle-plugin") }
        maven { url = uri("https://jitpack.io") }

        maven { url = uri("https://chaquo.com/maven") }
    }
}
rootProject.name = "BYOKGPT"
include(":app")
include(":xposed-api")
include(":xposed-runtime")
include(":ui-kit")
include(":remote-view")
include(":store")
include(":agent-runtime")

// 本地配置读取口：给 app 模块以外的模块按需依赖，见 xsettings/XSettings.kt 的「懒」规则。
include(":xsettings")

// Business 层：契约（api）与实现（agent）分离，业务方只依赖 api。
include(":business:api")
include(":business:agent")
include(":business:files")
include(":business:notification")
include(":business:application")
include(":business:permission")

// Vendored libraries (see libs/README.md)
include(":libs:logging")
include(":libs:okia")
include(":libs:libterm-core")
project(":libs:libterm-core").projectDir = file("libs/libterm/libterm-core")
include(":libs:libterm-runtime")
project(":libs:libterm-runtime").projectDir = file("libs/libterm/libterm-runtime")
include(":libs:libterm-backend-libsu")
project(":libs:libterm-backend-libsu").projectDir = file("libs/libterm/libterm-backend-libsu")
include(":libs:libterm-backend-shizuku")
project(":libs:libterm-backend-shizuku").projectDir = file("libs/libterm/libterm-backend-shizuku")
include(":libs:libterm-backend-ssh")
project(":libs:libterm-backend-ssh").projectDir = file("libs/libterm/libterm-backend-ssh")
